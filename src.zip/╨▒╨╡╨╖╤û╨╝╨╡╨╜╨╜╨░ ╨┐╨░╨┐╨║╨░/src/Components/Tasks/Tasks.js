import SimpleBar from 'simplebar-react';
import 'simplebar-react/dist/simplebar.min.css';
import Task from './Task';
import './Tasks.css';
import { useContext } from 'react';
import { MyData } from '../../context/dataContext';

function Tasks() {
  const { tasksList } = useContext(MyData);

  return (
    <SimpleBar style={{ maxHeight: 380, maxWidth: 710, margin: '0 auto' }} autoHide={true}>
      {tasksList &&
        tasksList.map((task) => {
          return <Task key={task.id} id={task.id} />;
        })}
    </SimpleBar>
  );
}

export default Tasks;
