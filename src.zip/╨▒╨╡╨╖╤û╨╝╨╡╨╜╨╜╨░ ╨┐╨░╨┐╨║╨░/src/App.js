import { useState, useEffect } from 'react';
import './App.css';
import './fonts.css';

import AddTask from './Components/newTask/AddTask';
import TaskCounter from './Components/taskCounter/TaskCounter';
import Tasks from './Components/Tasks/Tasks';
import { Provider } from './context/dataContext';

export const useStoreData = () => {
  // Get data from localstorage
  function getlocalData(name) {
    return localStorage.getItem(name) ? JSON.parse(localStorage.getItem(name)) : [];
  }

  const startTasks = getlocalData('tasklist');
  const completedTasklist = getlocalData('completed');
  const [tasksList, setTasksList] = useState(startTasks);
  const [complete, setComplete] = useState(completedTasklist);

  // Update localStorage
  useEffect(() => {
    localStorage.setItem('tasklist', JSON.stringify(tasksList));
  }, [tasksList]);

  useEffect(() => {
    localStorage.setItem('completed', JSON.stringify(complete));
  }, [complete]);

  return { tasklist: { tasksList, setTasksList }, completed: { complete, setComplete } };
};

function App() {
  return (
    <Provider>
      <div className="todolist">
        <h1 className="todolist__title">To do list</h1>
        <AddTask />
        <TaskCounter />
        <Tasks />
      </div>
    </Provider>
  );
}

export default App;
