import { useState, useRef, useContext} from 'react';
import style from './AddTask.module.css';
import { MyData } from '../../context/dataContext';

const useNewTask = () => {
  const storedIndex = localStorage.getItem('taskId') || 0;
  const taskId = useRef(storedIndex);
  const {setTasksList: updateData } = useContext(MyData);
  const [inputText, setInputText] = useState('');

  const submitHandler = (e) => {
    e.preventDefault();

    // Update ID
    taskId.current++;
    localStorage.setItem('taskId', taskId.current);

    // New task
    const formData = {
      id: taskId.current,
      title: inputText,
    };

    updateData((prevState) => [formData, ...prevState]);
    setInputText('');
  };
  const changeHandler = (e) => {
    setInputText(e.target.value);
  };

  return { inputText, submitHandler, changeHandler };
};

function AddTask() {
  const { inputText, submitHandler, changeHandler } = useNewTask();

  return (
    <form className={style.newtask} onSubmit={submitHandler}>
      <div className={style.newtask__body}>
        <input
          className={style.newtask__input}
          onChange={changeHandler}
          type="text"
          title="Task title"
          placeholder="New task..."
          value={inputText}
          required
          autoFocus
        />
        <button className={style.newtask__submit} type="submit">
          <span>Add</span>
        </button>
      </div>
    </form>
  );
}

export default AddTask;
