import { useStoreData } from '../App';
import { createContext } from 'react';


export const MyData = createContext();

export const Provider = ({ children }) => {
  const taskData = useStoreData().tasklist;
  const completedData = useStoreData().completed;

  return <MyData.Provider value={{...taskData, ...completedData}}>{children}</MyData.Provider>;
};
